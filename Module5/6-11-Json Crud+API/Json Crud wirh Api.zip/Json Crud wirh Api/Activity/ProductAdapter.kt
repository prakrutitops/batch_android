package tops.tech.jsonparsingex8.Activity

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import tops.tech.jsonparsingex8.R


class ProductAdapter(var context:Context, var list:MutableList<ProductModel>) :BaseAdapter()
{
    override fun getCount(): Int
    {
        return list.size
    }

    override fun getItem(position: Int): Any
    {
        return list.get(position)
    }

    override fun getItemId(position: Int): Long
    {
        return position.toLong()
    }

    @SuppressLint("MissingInflatedId")
    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View
    {
        var layout = LayoutInflater.from(parent!!.context)
        var view = layout.inflate(R.layout.design_product,parent,false)

        var txt1:TextView = view.findViewById(R.id.txt1)
        var txt2:TextView = view.findViewById(R.id.txt2)
        var txt3:TextView = view.findViewById(R.id.txt3)
        var img1:ImageView = view.findViewById(R.id.edit)
        var img2:ImageView = view.findViewById(R.id.delete)
        txt1.setText(list.get(position).p_name)
        txt2.setText(list.get(position).p_price)
        txt3.setText(list.get(position).p_des)

        img1.setOnClickListener {


            var i = Intent(context,UpdateProductActivity::class.java)
            i.putExtra("id",list.get(position).id)
            i.putExtra("name",list.get(position).p_name)
            i.putExtra("price",list.get(position).p_price)
            i.putExtra("des",list.get(position).p_des)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(i)


        }
        img2.setOnClickListener {

            var alert = AlertDialog.Builder(img2.context)
            alert.setTitle("Are you sure you want to delete?")
            alert.setPositiveButton("YES",{ dialogInterface: DialogInterface, i: Int ->

                var stringRequest: StringRequest = object : StringRequest(
                    Request.Method.POST,"https://vyasprakruti.000webhostapp.com/Shop_Crud_Api/adminproductdelete.php",
                    Response.Listener {

                        Toast.makeText(context,"Product Deleted", Toast.LENGTH_LONG).show()
                        var i = Intent(context,AdminProductViewActivity::class.java)
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(i)

                    },
                    {
                        Toast.makeText(context,"No Internet", Toast.LENGTH_LONG).show()

                    })
                {
                    override fun getParams(): MutableMap<String, String>?
                    {
                        var map = HashMap<String,String>()
                        map["id"]=list.get(position).id.toString()
                        return map
                    }


                }
                var queue: RequestQueue = Volley.newRequestQueue(context)
                queue.add(stringRequest)

            })
            alert.setNegativeButton("NO",{ dialogInterface: DialogInterface, i: Int ->

                dialogInterface.cancel()
            })
            alert.show()
        }

        return view
    }

}