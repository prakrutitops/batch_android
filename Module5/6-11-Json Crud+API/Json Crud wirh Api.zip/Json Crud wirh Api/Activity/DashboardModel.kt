package tops.tech.jsonparsingex8.Activity

class DashboardModel(var image:Int,var text:String)
{

}