package tops.tech.jsonparsingex8.Activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import tops.tech.jsonparsingex8.databinding.ActivityAddproductBinding

class AddProductActivity : AppCompatActivity()
{
    private lateinit var binding: ActivityAddproductBinding
    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        binding = ActivityAddproductBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        binding.btninsert.setOnClickListener {

            var pname = binding.edtpname.text.toString()
            var pprice = binding.edtpprice.text.toString()
            var pdes = binding.edtdes.text.toString()

            var stringRequest:StringRequest = object :StringRequest(Request.Method.POST,"https://vyasprakruti.000webhostapp.com/Shop_Crud_Api/adminproductinsert.php",
                Response.Listener {

                        Toast.makeText(applicationContext,"Product Inserted",Toast.LENGTH_LONG).show()
                        binding.edtpname.setText("")
                        binding.edtpprice.setText("")
                        binding.edtdes.setText("")

                },
                {
                    Toast.makeText(applicationContext,"No Internet",Toast.LENGTH_LONG).show()

                })
                {
                    override fun getParams(): MutableMap<String, String>?
                    {
                        var map = HashMap<String,String>()
                        map["p_name"]=pname
                        map["p_price"]=pprice
                        map["p_des"]=pdes

                        return map
                    }


                }
            var queue: RequestQueue = Volley.newRequestQueue(this)
            queue.add(stringRequest)




        }

    }
}