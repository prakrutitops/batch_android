package tops.tech.jsonparsingex8.Activity

class ProductModel
{
    var id=0
    var p_name=""
    var p_price=""
    var p_des=""
}