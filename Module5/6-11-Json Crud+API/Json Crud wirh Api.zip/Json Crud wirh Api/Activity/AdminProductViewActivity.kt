package tops.tech.jsonparsingex8.Activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONArray
import tops.tech.jsonparsingex8.databinding.ActivityAddproductBinding
import tops.tech.jsonparsingex8.databinding.ActivityAdminProductViewBinding

class AdminProductViewActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAdminProductViewBinding
    lateinit var list:MutableList<ProductModel>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAdminProductViewBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        list = ArrayList()

        var stringRequest = StringRequest(Request.Method.GET,"https://vyasprakruti.000webhostapp.com/Shop_Crud_Api/productview.php",{ response->
            try
            {
                var jsonArray = JSONArray(response)
                for(i in 0 until jsonArray.length())
                {
                    var jsonObject = jsonArray.getJSONObject(i)

                    var id = jsonObject.getInt("id")
                    var pname = jsonObject.getString("p_name")
                    var pprice = jsonObject.getString("p_price")
                    var pdes = jsonObject.getString("p_des")
                    var m = ProductModel()
                    m.id=id
                    m.p_name=pname
                    m.p_price = pprice
                    m.p_des=pdes
                    list.add(m)

                }
                var adapter = ProductAdapter(applicationContext,list)
                binding.list.adapter=adapter

            }
            catch (e:Exception)
            {
                e.printStackTrace()
            }
        })
        {
            Toast.makeText(applicationContext,"No Internet", Toast.LENGTH_LONG).show()
        }

        var queue: RequestQueue = Volley.newRequestQueue(this)
        queue.add(stringRequest)

    }
}