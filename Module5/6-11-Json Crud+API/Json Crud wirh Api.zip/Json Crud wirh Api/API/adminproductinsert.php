<?php
    
    include('connect.php');
    
    $name = $_POST["p_name"];
    $price = $_POST["p_price"];
    $des = $_POST["p_des"];
    
    if($name=="" && $price=="" && $des=="")
    {
        echo '0';
    }
    else
    {
        $sql = "insert into adminproductinsert (p_name,p_price,p_des) values ('$name','$price','$des')";
        
        mysqli_query($con,$sql);
        
        
    }
?>