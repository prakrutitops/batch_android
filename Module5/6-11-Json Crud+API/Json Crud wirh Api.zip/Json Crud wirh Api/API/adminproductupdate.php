<?php
    
    include('connect.php');
    
    $id = $_POST["id"];
    $pname = $_POST["p_name"];
    $price = $_POST["p_price"];
    $des = $_POST["p_des"];
    
    
    $sql ="update adminproductinsert set p_name='$pname',p_price='$price',p_des='$des' where id = '$id'";
    
    if(mysqli_query($con,$sql))
    {
        echo 'updated Succesfully';
    }
    else
    {
        echo 'something went wrong';
    }

?>