package com.example.giftshopproject.Adapters

import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import com.example.giftshopproject.Activity.CategoryActivity
import com.example.giftshopproject.Interface.Apiinterface
import com.example.giftshopproject.Model.CategoryDetailModel
import com.example.giftshopproject.Model.CategoryModel
import com.example.giftshopproject.R

import com.squareup.picasso.Picasso
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class CategoryAdapter(var context: Context,var list: List<CategoryDetailModel>):RecyclerView.Adapter<MyView2>()
{


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyView2
    {
        var  layoutInflater= LayoutInflater.from(parent.context)
        var view = layoutInflater.inflate(R.layout.design_category,parent,false)
        return MyView2(view)

    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: MyView2 , position: Int)
    {

        holder.textView.setText(list.get(position).pname)
        Picasso.get().load(list.get(position).pimage).into(holder.imageview)



    }
}
class MyView2(Itemview:View):RecyclerView.ViewHolder(Itemview)
{
    var textView: TextView = Itemview.findViewById(R.id.text)
    var imageview: ImageView = Itemview.findViewById(R.id.img)

}