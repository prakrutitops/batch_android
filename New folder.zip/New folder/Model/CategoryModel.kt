package com.example.giftshopproject.Model

class CategoryModel
{
    var id=0
    var category_name=""
    var category_img=""
}