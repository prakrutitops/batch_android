package com.example.giftshopproject.Model

class CategoryDetailModel
{
    var id=0
    var pname=""
    var pprice=0
    var pimage=""
    var pdes=""
}