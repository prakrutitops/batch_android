package com.example.giftshopproject.Activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.giftshopproject.Adapters.CategoryAdapter
import com.example.giftshopproject.Client.ApiClient
import com.example.giftshopproject.Interface.Apiinterface
import com.example.giftshopproject.Model.CategoryDetailModel
import com.example.giftshopproject.Model.CategoryModel
import com.example.giftshopproject.R
import com.example.giftshopproject.databinding.ActivityCategoryBinding
import com.example.giftshopproject.databinding.ActivityDashboardBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class CategoryActivity : AppCompatActivity()
{
    private lateinit var binding: ActivityCategoryBinding
    lateinit var apiinterface: Apiinterface
    lateinit var call: Call<List<CategoryDetailModel>>
    lateinit var list:MutableList<CategoryDetailModel>
    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        binding = ActivityCategoryBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        apiinterface=  ApiClient.getapiclient().create(Apiinterface::class.java)
        list = ArrayList()

        var layoutManager: RecyclerView.LayoutManager = GridLayoutManager(this,2)
        binding.recycler.layoutManager=layoutManager

        var i = intent
        var pos = i.getIntExtra("mypos",101)

        when(pos)
        {
            0->
            {
              call = apiinterface.chocolateviewdata()

            }
            1->
            {
                call = apiinterface.flowerviewdata()
            }
            2->
            {
                call = apiinterface.chocolateviewdata()
            }
        }
        call.enqueue(object:Callback<List<CategoryDetailModel>>
        {
            override fun onResponse(call: Call<List<CategoryDetailModel>>, response: Response<List<CategoryDetailModel>>) {


                list = response.body() as MutableList<CategoryDetailModel>

                var cadapter = CategoryAdapter(applicationContext,list)
                binding.recycler.adapter=cadapter
            }

            override fun onFailure(call: Call<List<CategoryDetailModel>>, t: Throwable) {

            }
        })



    }
}