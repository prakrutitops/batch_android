package com.example.giftshopproject.Activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.giftshopproject.R
import com.example.giftshopproject.databinding.ActivityCategoryBinding
import com.example.giftshopproject.databinding.ActivityDashboardBinding
import com.example.giftshopproject.databinding.ActivityFullScreenImageBinding
import com.squareup.picasso.Picasso

class FullScreenImageActivity : AppCompatActivity()
{
    private lateinit var binding: ActivityFullScreenImageBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFullScreenImageBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        var i = intent
        var id = i.getIntExtra("id",101)
       var price= i.getIntExtra("price",0)
        binding.txt1.setText( i.getStringExtra("name"))
        binding.txt2.setText(price.toString())
        binding.txt3.setText(  i.getStringExtra("des"))
        //binding.photoView.setImageResource(i.getStringExtra("image"))
        Picasso.get().load(i.getStringExtra("image")).into(binding.photoView)




    }
}