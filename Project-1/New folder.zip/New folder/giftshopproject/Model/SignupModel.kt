package com.example.giftshopproject.Model

class SignupModel
{

}